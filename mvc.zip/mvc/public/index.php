<?php
    declare(strict_types = 1);

    require_once("../config/database.php");

    require_once("../autoload.php");

    require_once("../routes/web.php");
?>

<!-- <code>Unico punto de acceso</code> -->