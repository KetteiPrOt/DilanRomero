<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pagina Principal (Test)</title>
</head>
<body>
    <p>Hola desde la pagina homeTest</p>

    <h3>Registro</h3>
    <p>
    <?= "<strong>Usuario:</strong> $nombre<br> <strong>Correo:</strong> $email<br> <strong>Telefono:</strong> $telefono<br>" ?>
    </p>
</body>
</html>