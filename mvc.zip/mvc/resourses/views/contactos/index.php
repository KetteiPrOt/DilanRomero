<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listado de Contactos</title>
</head>
<body>
    <h1>Indice</h1>

    <?php
        $contactos = "registros";
    ?>

    <p><a href="contactos/crear">Nuevo Contacto</a></p>

    <form action="/contactos">
        <button type="submit">Buscar</button>
        <input type="text" name="buscar">
    </form>

    <?php foreach ($$contactos as $contacto): ?>
        <?php
            $id = $contacto["id"];
            $nombre = $contacto["nombre"];
            $telefono = $contacto["telefono"];
            // extract($contacto);
        ?>

        <ul>
            <a href="/contactos/<?= $id ?>">
                <li>
                    <strong>Nombre:</strong> <?= $nombre ?>
                </li>
                <li>
                    <strong>Telefono:</strong> <?= $telefono ?>
                </li>
            </a>
        </ul>
    <?php endforeach ?>

    <?php require_once("../resourses/views/assets/pagination.php"); ?>
</body>
</html>