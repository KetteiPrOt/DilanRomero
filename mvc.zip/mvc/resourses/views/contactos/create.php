<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear</title>
</head>
<body>
    <h1>Crear Contacto</h1>

    <a href="/contactos">Volver</a> <br><br>

    <form action="/contactos" method="post">
        <fieldset>
            <legend>Datos</legend>

            <label for="nombre">Nombre: </label>
            <input type="text" name="nombre" id="nombre"> <br><br>

            <label for="apellido">Apellido: </label>
            <input type="text" name="apellido" id="apellido"> <br><br>

            <label for="telefono">Telefono: </label>
            <input type="text" name="telefono" id="telefono"> <br><br>

            <label for="comentario">Comentario: </label><br>
            <textarea name="comentario" id="comentario" cols="30" rows="10"></textarea> <br><br>

            <button type="submit">Guardar</button>
        </fieldset>
    </form>
</body>
</html>