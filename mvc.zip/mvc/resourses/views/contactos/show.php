<?php
    $id = $contacto["id"];

    array_shift($contacto);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contacto</title>
</head>
<body>
    <h1>Detalles</h1>

    <a href="/contactos">Volver</a>

    <ul>
        <?php foreach ($contacto as $columna => $dato): ?>
            <li>
                <?= "$columna: $dato" ?>
            </li>
        <?php endforeach ?>
    </ul>

    <a href="/contactos/<?= $id ?>/editar">Editar</a> <br><br>

    <form action="/contactos/<?= $id ?>/eliminar" method="post">
        <button type="submit">Eliminar Contacto</button>
    </form>
</body>
</html>