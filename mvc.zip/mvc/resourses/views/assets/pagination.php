<p>Mostrando <?= $actual ?> hasta <?= $tope ?> de <?= $total ?> resultados.</p>

<?php
    if (isset($valor)) { $buscar = "&buscar=$valor"; } else { $buscar = ""; }

    if ($prev_page_url) {
        echo "<a href=\"$prev_page_url" . "$buscar\">Anterior</a> <br>";
    }

    for ($i = 1; $i <= $ultimaPagina; $i++) {
        echo "<a href=\"/contactos?page=$i" . "$buscar\">Pagina $i</a> <br>";
    }

    if ($next_page_url) {
        echo "<a href=\"$next_page_url" . "$buscar\">Siguiente</a> <br>";
    }
?>