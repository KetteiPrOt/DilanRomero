<?php

define("DB_HOST", "192.168.100.85");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "mydb");