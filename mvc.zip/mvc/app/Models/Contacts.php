<?php

namespace app\Models;

// El autoload esta cargando el archivo "/app/Models/Model.php" al extender la clase
class Contacts extends Model
{
    protected $table = "contacts";
}