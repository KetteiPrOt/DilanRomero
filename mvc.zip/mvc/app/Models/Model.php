<?php

namespace app\Models;

use mysqli;

class Model {
    protected $db_host = DB_HOST,
              $db_user = DB_USER,
              $db_pass = DB_PASS,
              $db_name = DB_NAME;

    protected $connection,
              $query;

    public function __construct() {
        $this->connect();
    }

    protected function connect() {

        $this->connection = new mysqli($this->db_host, $this->db_user, $this->db_pass, $this->db_name);

        // Si tenemos un error de conexion detiene la ejecucion del programa
        $error = $this->connection->connect_error;

        if ($error) {
            die("Error de conexion: " . $error);
        }
        
    }

    protected function query(string $sql, array $data = [], string $params = null): object
    {   
        if ($data) {

            // Consulta Preparada

            // Si no hay tipos, por defecto los toma como strings
            if (!$params) {
                
                $params = str_repeat('s', count($data));

                // echo 'Ejecutado Parametros';

            }

            // $data = [1]; $params = 's'

            $stmt = $this->connection->prepare($sql);

            $stmt->bind_param($params, ...$data);

            $stmt->execute();

            $resultado_consulta = $stmt->get_result();

            $this->query = $resultado_consulta;

            return $this;
    
        } else {

            // Consulta normal

            $this->query = $this->connection->query($sql);

            return $this;

        }
    }

    public function first(): array
    {
        $resultado = $this->query->fetch_assoc();

        return $resultado;
    }

    public function get(): array
    {
        $resultado = $this->query->fetch_all(MYSQLI_ASSOC);

        return $resultado;
    }

    // Consultas
    public function all(): array
    {
        $sql = "SELECT * FROM {$this->table}";

        return $this->query($sql)->get();
    }

    public function find(int $id): array
    {
        $sql = "SELECT * FROM {$this->table} WHERE id = ?";

        return $this->query($sql, [$id], 'i')->first();
    }

    public function where(string $column, string | int $operator, string | int $value = null): object
    {
        // Si solo hay dos parametros el segundo corresponde al value, y por defecto es igualdad
        if ($value == null) {
            $value = $operator;
            $operator = "=";
        } 

        $sql = "SELECT * FROM {$this->table} WHERE $column $operator ?";

        // Es nesesario especificar cuantos registros retornar encadenando con first() [si deseea uno] o con get() [si deseea todos]
        return $this->query($sql, [$value]);
    }

    // Insertar
    public function create(array $data, string $params = null): array
    {
        $columns = implode(", ", array_keys($data)); // key_1, key_2, key_3

        $values = array_values($data);

        $sql = "INSERT INTO {$this->table} ($columns) VALUES (" . str_repeat("?, ", count($data) - 1) . " ?);";

        // INSERT INTO persons (
        //     nombre, email, telefono)
        // VALUES (?, ?, ?,...);

        $this->query($sql, $values, $params);

        // La propiedad insert_id contiene el ultimo id insertado en la tabla
        $insert_id = $this->connection->insert_id;

        // Retorna el ultimo registro creado por si deseeamos mostrarlo en la pantalla
        return $this->find($insert_id);
    }

    // Actualizar
    public function update(int | string $id, array $data, string $params = null): array
    {
        $fields = [];

        foreach ($data as $key => $value) {
            $fields[] = "$key = ?";
        }

        $values = array_values($data);
        $values[] = $id;
        
        $fields = implode(", ", $fields);

        $sql = "UPDATE {$this->table} SET $fields WHERE id = ?;";
        // UPDATE nombre_tabla SET
        //     columna_1 = ?,
        //     columna_2 = ?,
        //     columna_3 = ?
        //     ...
        // WHERE id = ?;

        $this->query($sql, $values, $params);

        return $this->find($id);
    }

    // Eliminar
    public function delete(int | string $id): string
    {
        // DELETE FROM nombre_tabla WHERE id = 1;
        $sql = "DELETE FROM {$this->table} WHERE id = ?;";

        $this->query($sql, [$id], 'i');

        return "Registro $id Eliminado";
    }

    // --- --- --- Paginar

    public function paginate(int $cant = 10, array $buscar = null): array
    {
        // Recupera la pagina por la URL, si no hay le da el valor de 1
        $pagina = isset($_GET["page"]) ? $_GET["page"] : 1;

        // Cuando $pagina aumenta en 1, $actual aumenta en el valor de $cant
        $actual = $cant * ($pagina - 1);

        // Consulta a la base de datos y guarda la cantidad total de registros
        if ($buscar) {

            extract($buscar); // $column = $buscar["column"], $operator = $buscar["operator"] ...;

            $sql = "SELECT SQL_CALC_FOUND_ROWS * FROM {$this->table} WHERE $columna $operador ? LIMIT ?, {$cant};";

            $registros = $this->query($sql, ["$valor%", $actual], "si")->get(); // [ [], [], [], ... ]

        } else {

            $sql = "SELECT SQL_CALC_FOUND_ROWS * FROM {$this->table} LIMIT ?, {$cant};";

            $registros = $this->query($sql, [$actual], "i")->get(); // [ [], [], [], ... ]

        }

        // Reupera la cantidad total de registros
        $cantidad = $this->query("SELECT FOUND_ROWS() AS total")->first();
        
        // Obtiene la ultima pagina
        $ultimaPagina = ceil($cantidad["total"] / $cant);

        // Obtener URI sin variables GET
        $requestUri = $_SERVER["REQUEST_URI"];

        if (str_contains($requestUri, "?")) {

            $uriLen = strpos($requestUri, "?");

            $requestUri = substr($requestUri, 0, $uriLen);
        }

        $requestUri = trim($requestUri, "/");

        // Definir las URIs de prev y next con la URI obtenida
        $next_page_url = "/" . $requestUri . "?page=" . $pagina + 1;
        $prev_page_url = "/" . $requestUri . "?page=" . $pagina - 1;

        return [
            "registros" => $registros, // [ [], [], [], ... ]
            "actual" => ($cant * ($pagina - 1)) + 1,
            "tope" => ($cant * ($pagina - 1)) + count($registros),
            "prev_page_url" => $pagina > 1 ? $prev_page_url : null,
            "next_page_url" => $pagina < $ultimaPagina ? $next_page_url : null,
            "ultimaPagina" => $ultimaPagina,
            "total" => $cantidad["total"],
            "valor" => isset($valor) ? $valor : null
        ];
    }
}