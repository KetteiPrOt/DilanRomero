<?php

namespace app\Models;

// El autoload esta cargando el archivo "/app/Models/Model.php" al extender la clase
class Persons extends Model
{
    protected $table = "persons";
}