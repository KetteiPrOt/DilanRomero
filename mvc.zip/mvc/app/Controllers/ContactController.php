<?php

namespace app\Controllers;

// El autoload cargara el archivo "/app/Models/Contacts.php" al instanciar la clase
use app\Models\Contacts;

// El autoload esta cargando el archivo "/app/Controllers/Controller.php" al extender la clase
class ContactController extends Controller {

    public function index(): string
    {
        $contactsModel = new Contacts;

        if (isset($_GET["buscar"])) {

            $buscar = [
                "columna" => "nombre",
                "operador" => "LIKE",
                "valor" => $_GET["buscar"],
            ];

            $informacion = $contactsModel->paginate(10, $buscar);

            return $this->view("contactos.index", $informacion);

        } else {

            $informacion = $contactsModel->paginate();

            // $informacion =  [
            //     "contactos" => $contactos, // [ [], [], [], ... ]
            //     "actual" => ($cant * ($pagina - 1)) + 1,
            //     "tope" => ($cant * ($pagina - 1)) + count($contactos),
            //     "prev_page_url" => $pagina > 1 ? $prev_page_url : null,
            //     "next_page_url" => $pagina < $ultimaPagina ? $next_page_url : null,
            //     "ultimaPagina" => $ultimaPagina,
            //     "total" => $cantidad["total"]
            // ];
            
            return $this->view("contactos.index", $informacion);
            // return $informacion;

        }
    }

    public function create(): string
    {
        return $this->view("contactos.create");
        // return "Mostrara un formulario para crear un contacto";
    }

    public function store() 
    {
        // Retornar parametros del formulario
        $data = $_POST;

        $contactsModel = new Contacts;

        // Hacer la consulta a la base de datos y redirigir a inicio
        $contactsModel->create($data);

        $this->redirect("Location: /contactos");
        // Registro Creado:
        // return $contactsModel->create($data);
        // return "Procesara la informacion recibida para crear un contacto";
    }

    public function show($id): string
    {
        // Recuperar el la informacion del contacto y mostrarla por la vista
        $contactsModel = new Contacts;

        $contacto = $contactsModel->find($id);

        return $this->view("contactos.show", compact("contacto"));
        // return "Mostrara un contacto con id: $id";
    }

    public function edit($id): string
    {
        $contactsModel = new Contacts;

        $contacto = $contactsModel->find($id);

        // return $contacto;
        return $this->view("contactos.edit", $contacto);
        // return "Mostrara un formulario para editar un contacto con id: $id";
    }

    public function update($id)
    {
        // Retornar parametros del formulario
        $data = $_POST;

        $contactsModel = new Contacts;

        // Hacer la consulta a la base de datos y redirigir a inicio
        $contactsModel->update($id, $data);

        $this->redirect("Location: /contactos/$id");
        // return "Procesara la informacion recibida para editar un contacto con id: $id";
    }

    public function destroy($id)
    {
        $contactsModel = new Contacts;

        // Hacer la consulta a la base de datos y redirigir a inicio
        $contactsModel->delete($id);

        $this->redirect("Location: /contactos");
        // return "Eliminara un contacto con id: $id";
    }

}