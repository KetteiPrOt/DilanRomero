<?php

namespace app\Controllers;

class Controller {

    public function view(string $path, array $data = []): string
    {
        // Destructurar el Arreglo $data
        extract($data);

        $path = str_replace(".", "/", $path);
               
        $route = "../resourses/views/$path.php";

        // Esta sentencia se esta ejecutando en el archivo /public/index.php
        if (file_exists($route)) {
            
            ob_start();

            include($route);

            $content = ob_get_clean();

            return $content;

        } else {
            echo "El archivo no existe";
        }
    }

    public function redirect(string $route) 
    {
        header($route);
    }

}