<?php

namespace app\Controllers;

// El autoload cargara el archivo "/app/Models/Persons.php" al instanciar la clase
use app\Models\Persons;

// El autoload esta cargando el archivo "/app/Controllers/Controller.php" al extender la clase
class HomeController extends Controller {

    public function index(): mixed
    {
        $personsModel = new Persons;

        // Hace la consulta a la base de datos y obtener los datos
        $registro = $personsModel->find(2);

        return $this->view("prueba.homeTest", $registro);

        // return $this->view("prueba.homeTest", [
        //     "nombre" => "Joel",
        //     "correo" => "joel.mt@gamil.com",
        //     ...
        // ]);
    }

}