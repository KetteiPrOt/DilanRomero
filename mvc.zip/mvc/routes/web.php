<?php

use Lib\Route; // Carga el archivo Route.php automaticamente gracias al autoload

use app\Controllers\HomeController; // Carga el archivo HomeController.php automaticamente gracias al autoload

use app\Controllers\ContactController; // Carga el archivo ContactController.php automaticamente gracias al autoload

Route::get("/", [HomeController::class, "index"]);

Route::get("/contactos", [ContactController::class, "index"]);

Route::get("/contactos/crear", [ContactController::class, "create"]);

Route::post("/contactos", [ContactController::class, "store"]);

Route::get("/contactos/:id", [ContactController::class, "show"]);

Route::get("/contactos/:id/editar", [ContactController::class, "edit"]);

Route::post("/contactos/:id", [ContactController::class, "update"]);

Route::post("/contactos/:id/eliminar", [ContactController::class, "destroy"]);

// Route::get("/cursos/:slug", function (string $slug) {
//     return "Valor de slug: $slug <br>";
// });

Route::dispatch();