<?php

spl_autoload_register(function($namespace) {
    // use namepace\Clase
    // $objeto = new Clase;
    // echo $namesapce; // namepace\Clase
    $ruta = "../" .  str_replace("\\", "/", $namespace) . ".php";

    if (file_exists($ruta)) {        
        require_once($ruta);
    } 
    else {
        echo "No se pudo cargar el archivo: " . $ruta;
    }
});