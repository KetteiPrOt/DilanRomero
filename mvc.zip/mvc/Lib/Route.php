<?php

namespace Lib;

class Route {
    // Almacena las rutas de los metodos GET y POST en dos Arreglos
    private static $routes = [
        "get" => [], "post" => []
        // "get" => [
        //     "uri" => "Funcion callback redirectora"
        // ],
        // "post" => [
        //     "uri" => "Funcion callback redirectora"
        // ]
    ];

    public static function get(string $uri, $callback)
    {
        // Agrega una nueva ruta uri como llave literal al Arreglo GET y le asigna una funcion callback como valor
        $uri = trim($uri, "/");

        $arrayGET = &self::$routes["GET"];
        $arrayGET[$uri] = $callback;
    }

    public static function post(string $uri, $callback)
    {
        // Agrega una nueva ruta uri como llave literal al Arreglo POST y le asigna una funcion callback como valor
        $uri = trim($uri, "/");

        $arrayPOST = &self::$routes["POST"];
        $arrayPOST[$uri] = $callback;
    }

    public static function dispatch()
    {
        $requestUri = $_SERVER["REQUEST_URI"]; // URL: /mvc.test URI: /contactos/

        // Si hay paginacion en la URL la detecta y la aparta
        if (str_contains($requestUri, "?")) {
            // URL: /mvc.test URI: /contactos/?page=1
            $uriLen = strpos($requestUri, "?");
            // URI: /contactos/
            $requestUri = substr($requestUri, 0, $uriLen);
        }

        $requestUri = trim($requestUri, "/"); // URL: /mvc.test URI: contactos

        $method = $_SERVER["REQUEST_METHOD"]; // get o post

        /*
        Evaluar si la URI solicitada existe dentro del sitio web, si la tenemos guardada en los Arreglos GET o POST
        */
        $array = &self::$routes[$method];
        
        foreach ($array as $uri => $callback) {

            // Si hay un :slug en la URI guardada lo convierte en una expresion regular ([\w|-]+)
            if (str_contains($uri, ":")) {

                $uri = preg_replace("%:([\w|-])+%", "([\w|-]+)", $uri);
                // echo $uri . "<br>"; // Mostrar nueva URI

            }
            
            // Evaluar la URI solicitada con la expresion regular
            $expresion = "%^$uri$%";

            $tenemosLaUri = preg_match($expresion, $requestUri, $matches);

            if ($tenemosLaUri) {
                
                // Borra el primer elemento del array matches (porque contiene toda la URI y solo queremos los datos capturados)
                $params = array_slice($matches, 1);
                
                if (is_callable($callback)) {

                    $response = $callback(...$params);

                } elseif (is_array($callback)) {

                    $claseNamespace = $callback[0]; $nombreMetodo = $callback[1];

                    $controller = new $claseNamespace;

                    $response = $controller->{$nombreMetodo}(...$params);

                }

                if (is_array($response) || is_object($response)) {

                    print_r($response);

                } else {
                    echo $response;
                }

                return; // Redirigido a la pagina solicitada, ejecucion de la funcion finalizada

            }
            
        }

        // La pagina solicitada no fue encontrada
        echo "Error 404: no hemos encontrado la pagina solicitada en nuestro sitio.";
    }
}

?>